import {bundle} from '@remotion/bundler';
import {openBrowser,selectComposition,renderStill} from '@remotion/renderer';
import path from 'node:path';
const root='/private/tmp/astra-social-film';
const serveUrl=await bundle({entryPoint:path.join(root,'src/index.ts'),rootDir:root,outDir:path.join(root,'out/inspection-bundle'),publicDir:path.join(root,'public')});
const browser=await openBrowser('chrome',{chromiumOptions:{gl:'angle'}});
try {
 const composition=await selectComposition({serveUrl,id:'Astra-Twitter-30s',puppeteerInstance:browser});
 for(const frame of [48,180,312,456,564,666]) {
  await renderStill({serveUrl,composition,output:path.join(root,'out',`frame-${frame}.png`),frame,puppeteerInstance:browser,timeoutInMilliseconds:180000,overwrite:true});
  console.log(`Rendered teaser inspection frame ${frame}.`);
 }
} finally {await browser.close({silent:true});}
