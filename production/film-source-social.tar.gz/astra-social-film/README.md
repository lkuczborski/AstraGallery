# Astra Gallery — 30-second landscape teaser

A 30-second invitation to the Codex Billboards collection: 358 works across 26 rooms, followed by the open studio and a five-second invitation with the gallery URL and Jess credit. The composition is `Astra-Twitter-30s`: 1920×1080, 24 fps, 720 frames.

The finished media is `out/astra-gallery-twitter-30s.mp4`. Production details, the exact picture/audio edits, provenance, and final validation are in [PRODUCTION.md](PRODUCTION.md). The source archive excludes dependency installations, rendered outputs, artwork/model/texture assets, and audio WAVs.

## Restore dependencies and external assets

Run commands from the extracted project directory. `package-lock.json` pins the dependency graph. The archived `src/gallery` snapshot and recorded lighting files must stay together.

```sh
npm ci
mkdir -p public/media
```

Restore these six directories under `public/`: `artworks`, `thumbs`, `avatars`, `brand`, `models`, and `textures`. On the original host they come from `/Users/luku/Developer/AstraGallery/public`. Copy them from that saved asset set, or create the same local symlinks:

```sh
ASTRA_ASSET_ROOT=/Users/luku/Developer/AstraGallery/public
for asset in artworks thumbs avatars brand models textures; do
  ln -s "$ASTRA_ASSET_ROOT/$asset" "public/$asset"
done
```

The source score is `/private/tmp/astra-film-v2/public/media/astra-rooms-of-light-120s.wav`. Its reproduction scripts are preserved in `/Users/luku/Developer/AstraGallery/production/audio-v2/astra-soundtrack-120s-source.zip`. It is the existing 120-second original Astra score; no new music was generated for this teaser. `audio/render_audio.py` is an unchanged copy of the original audio edit script. It uses that absolute source path and `/opt/homebrew/bin/ffmpeg` plus `/opt/homebrew/bin/ffprobe`; change its three path constants if restoring elsewhere.

```sh
python3 audio/render_audio.py
cp audio/astra-social-30s.wav public/media/astra-social-30s.wav
mkdir -p out
```

The script also writes an AAC audio preview and validation JSON beside itself. The archived original validation describes the delivered 30-second WAV. The two recorded lighting files already reside in `public/media` and must not be replaced by the audio step.

## Exact production commands

Render the scene and named overlays:

```sh
npx remotion render src/index.ts Astra-Twitter-30s out/astra-gallery-twitter-30s-render.mp4 --codec=h264 --crf=23 --concurrency=1 --audio-bitrate=160k --jpeg-quality=94 --x264-preset=slow
```

Create the final compatible MP4. This converts the rendered full-range signal to TV range and explicitly encodes H.264/yuv420p and stereo AAC from the edited WAV:

```sh
ffmpeg -hide_banner -loglevel error -y -i out/astra-gallery-twitter-30s-render.mp4 -i public/media/astra-social-30s.wav -map 0:v:0 -map 1:a:0 -vf scale=in_range=pc:out_range=tv -c:v libx264 -preset slow -crf 18 -pix_fmt yuv420p -color_range tv -profile:v high -level:v 4.1 -maxrate 12M -bufsize 24M -c:a aac -b:a 160k -ar 48000 -t 30 -movflags +faststart out/astra-gallery-twitter-30s.mp4
```

This second encode is part of the actual production recipe. Do not apply its full-range-to-TV conversion again to the final output.

```sh
ffprobe -v error -show_streams -show_format -of json out/astra-gallery-twitter-30s.mp4
ffmpeg -v error -i out/astra-gallery-twitter-30s.mp4 -f null -
shasum -a 256 out/astra-gallery-twitter-30s.mp4
```

`inspect-social.mjs` reproduces the six inspection stills. Its `root` constant points to the original `/private/tmp/astra-social-film` workspace; update it if the project has moved. No MP4 or new render was read or run while preparing this archive.

Rebuild this compact source package with `python3 scripts/package-source.py`. The packager never reads rendered media or external assets.
