"""Package only reproducible teaser inputs; never read rendered media/assets."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parent.parent
ARCHIVE = ROOT / 'astra-social-source.tar.gz'
BASE = ['README.md', 'PRODUCTION.md', 'package.json', 'package-lock.json',
        'tsconfig.json', 'remotion.config.ts', 'inspect-social.mjs',
        'public/media/lighting-v3.bin', 'public/media/lighting-v3.json']
paths = {ROOT / name for name in BASE}
for directory, suffixes in [('src', {'.ts', '.tsx', '.css', '.json'}),
                            ('audio', {'.py', '.json'}),
                            ('scripts', {'.py'}), ('docs', {'.json', '.md'})]:
    paths.update(p for p in (ROOT / directory).rglob('*')
                 if p.is_file() and not p.is_symlink() and p.suffix in suffixes)
manifest_path = ROOT / 'docs/source-manifest.json'
paths.discard(manifest_path)
entries = []
for path in sorted(paths):
    data = path.read_bytes()
    entries.append({'path': path.relative_to(ROOT).as_posix(),
                    'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
manifest = {
    'project': 'Astra-Twitter-30s',
    'picture': {'width': 1920, 'height': 1080, 'fps': 24, 'frames': 720},
    'externalArtAssets': '/Users/luku/Developer/AstraGallery/public/{artworks,thumbs,avatars,brand,models,textures}',
    'externalSourceScore': '/private/tmp/astra-film-v2/public/media/astra-rooms-of-light-120s.wav',
    'sourceScoreReproductionArchive': '/Users/luku/Developer/AstraGallery/production/audio-v2/astra-soundtrack-120s-source.zip',
    'deliveredMedia': {'path': 'out/astra-gallery-twitter-30s.mp4',
        'bytes': 11691233,
        'sha256': 'b08ccb9057cb3cf268ccfbf7bbbf0644acaf2a96144a1bcc45c60b1433b617da',
        'validation': 'Final metadata, full decode and faststart confirmation supplied by parent production task; this packager never reads media.'},
    'manifestNote': 'This manifest excludes its own hash.',
    'files': entries,
}
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
paths.add(manifest_path)
with ARCHIVE.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as tar:
            for path in sorted(paths):
                data = path.read_bytes()
                info = tarfile.TarInfo('astra-social-film/' + path.relative_to(ROOT).as_posix())
                info.size = len(data)
                info.mode = 0o644
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ''
                tar.addfile(info, io.BytesIO(data))
print(json.dumps({'archive': str(ARCHIVE), 'files': len(paths),
                  'bytes': ARCHIVE.stat().st_size,
                  'sha256': hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()}))
