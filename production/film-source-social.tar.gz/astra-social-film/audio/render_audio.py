"""Reproduce the 30-second teaser edit using only the existing Astra master."""
from pathlib import Path
from array import array
import json
import math
import subprocess

HERE = Path(__file__).resolve().parent
SOURCE = Path('/private/tmp/astra-film-v2/public/media/astra-rooms-of-light-120s.wav')
FFMPEG = '/opt/homebrew/bin/ffmpeg'
FFPROBE = '/opt/homebrew/bin/ffprobe'
WAV = HERE / 'astra-social-30s.wav'
AAC = HERE / 'astra-social-30s.m4a'

def run(args):
    return subprocess.run(args, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

# Keep the original 96 BPM grid. Each 80 ms linear crossfade is centered
# 50 ms before the next downbeat, so it finishes before the incoming attack.
graph = (
    '[0:a]aresample=48000,asplit=3[a][b][c];'
    '[a]atrim=start=42.8:end=50.34,asetpts=PTS-STARTPTS,'
    'afade=t=in:st=0:d=0.025:curve=qsin[a1];'
    '[b]atrim=start=55.26:end=70.34,asetpts=PTS-STARTPTS[b1];'
    '[c]atrim=start=110.26:end=117.8,asetpts=PTS-STARTPTS,volume=3dB[c1];'
    '[a1][b1]acrossfade=d=0.08:c1=tri:c2=tri[ab];'
    '[ab][c1]acrossfade=d=0.08:c1=tri:c2=tri,'
    'afade=t=out:st=28.4:d=1.6:curve=qsin,volume=-0.6dB,'
    'atrim=end_sample=1440000[out]'
)
metadata = [
    '-metadata', 'title=Astra - Rooms of Light (30-second teaser)',
    '-metadata', 'artist=Original score for Astra Gallery',
    '-metadata', 'comment=Edited exclusively from the existing Astra original score; 96 BPM; D major; 30.000 seconds.'
]
run([FFMPEG, '-v', 'error', '-y', '-i', str(SOURCE), '-filter_complex', graph,
     '-map', '[out]', '-c:a', 'pcm_s24le', '-ar', '48000'] + metadata + [str(WAV)])
run([FFMPEG, '-v', 'error', '-y', '-i', str(WAV), '-c:a', 'aac', '-b:a', '192k',
     '-movflags', '+faststart'] + metadata + [str(AAC)])

def measure(path):
    probe = json.loads(run([FFPROBE, '-v', 'error', '-show_entries',
        'stream=codec_name,sample_rate,channels,bits_per_raw_sample:format=duration,size',
        '-of', 'json', str(path)]).stdout)
    analysis = run([FFMPEG, '-hide_banner', '-i', str(path), '-af',
        'loudnorm=I=-17:TP=-1.5:LRA=14:print_format=json', '-f', 'null', '-']).stderr.decode()
    loudness = json.loads(analysis[analysis.rfind('{'):analysis.rfind('}')+1])
    data = array('f')
    data.frombytes(run([FFMPEG, '-v', 'error', '-i', str(path), '-f', 'f32le',
        '-ar', '48000', '-ac', '2', '-']).stdout)
    peak = max(abs(x) for x in data)
    return dict(probe=probe, decoded_frames=len(data)//2,
        decoded_duration=len(data)/2/48000,
        integrated_lufs=float(loudness['input_i']),
        true_peak_dbtp=float(loudness['input_tp']),
        loudness_range_lu=float(loudness['input_lra']),
        sample_peak_dbfs=20*math.log10(peak),
        clipped_samples=sum(abs(x)>=1.0 for x in data),
        finite=all(math.isfinite(x) for x in data),
        final_sample=data[-2:],
        last_100ms_peak_dbfs=20*math.log10(max(abs(x) for x in data[-9600:]) or 1e-12))

validation = {p.suffix[1:]:measure(p) for p in (WAV, AAC)}
for v in validation.values():
    v['final_sample'] = list(v['final_sample'])
    assert v['clipped_samples'] == 0 and v['finite']
    assert -18 <= v['integrated_lufs'] <= -16
    assert v['true_peak_dbtp'] <= -1.5
assert validation['wav']['decoded_frames'] == 1440000
(HERE/'validation.json').write_text(json.dumps(validation, indent=2))
edl = dict(source=str(SOURCE), duration=30.0, sample_rate=48000, channels=2,
    bpm=96, key='D major', global_gain_db=-0.6,
    sections=[
        dict(source_in=42.8, source_out=50.34, output_in=0, output_out=7.54,
             purpose='Clear D-major piano opening, then Em-A lead-in', gain_db=0),
        dict(source_in=55.26, source_out=70.34, output_in=7.46, output_out=22.54,
             purpose='Six-bar main rise: Bm-G-D-A-G-D', gain_db=0),
        dict(source_in=110.26, source_out=117.8, output_in=22.46, output_out=30.0,
             purpose='Original A-to-D ending and final piano answer', gain_db=3)
    ],
    crossfades=[dict(start=7.46, end=7.54, curve='linear'),
                dict(start=22.46, end=22.54, curve='linear')],
    fades=[dict(start=0,end=0.025,type='in',curve='quarter sine'),
           dict(start=28.4,end=30,type='out',curve='quarter sine')],
    picture_cues=[dict(time=0.05,label='First D-major downbeat'),
                  dict(time=7.55,label='Main rise enters'),
                  dict(time=22.55,label='Final A chord begins'),
                  dict(time=25.05,label='Final D-major chord lands'),
                  dict(time=26.1125,label='Final D melody note answers'),
                  dict(time=28.4,label='Short final fade begins')],
    processing='Resampling, two short crossfades, level balance, and fades only. No new music, tempo change, looping, compression, or limiting.')
(HERE/'edit-decision-list.json').write_text(json.dumps(edl,indent=2))
print(json.dumps(validation,indent=2))
