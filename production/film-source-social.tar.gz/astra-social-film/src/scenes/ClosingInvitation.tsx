import React from 'react';
import {AbsoluteFill,CanvasImage,Interactive,interpolate,staticFile,useCurrentFrame} from 'remotion';
export const ClosingInvitation:React.FC=()=>{
 const frame=useCurrentFrame();
 return <AbsoluteFill style={{alignItems:'center',justifyContent:'center',padding:'95px 120px',background:'#101b1c',color:'#eee4cd',opacity:interpolate(frame,[0,10],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>
  <CanvasImage src={staticFile('brand/astra-gallery-logo-v2.png')} width={1100} height={1100/3}/>
  <Interactive.Div name="Invitation" style={{fontFamily:'Georgia, serif',fontSize:80,marginTop:-15}}>Step inside.</Interactive.Div>
  <Interactive.Div name="Gallery URL" style={{fontFamily:'Arial, sans-serif',fontSize:50,letterSpacing:.2,marginTop:34,color:'#f2dfb9'}}>astra-gallery.lkuczborski.chatgpt.site</Interactive.Div>
  <Interactive.Div name="Original project credit" style={{fontFamily:'Arial, sans-serif',fontSize:34,lineHeight:1.5,marginTop:64,color:'#b4c0bb'}}>Original Codex Billboards project by Jess · @itsjessyin</Interactive.Div>
 </AbsoluteFill>;
};
