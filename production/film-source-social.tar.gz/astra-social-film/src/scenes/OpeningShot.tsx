import React from 'react';
import {AbsoluteFill,Interactive,interpolate,useCurrentFrame} from 'remotion';
export const OpeningShot:React.FC=()=>{
 const frame=useCurrentFrame();
 return <AbsoluteFill style={{justifyContent:'flex-end',padding:'0 110px 112px',color:'#f0e7d4',background:'linear-gradient(0deg,rgba(9,16,19,.88),transparent 58%)',opacity:interpolate(frame,[0,10,99,119],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>
  <Interactive.Div name="Exhibition title" style={{fontFamily:'Georgia, serif',fontSize:118,lineHeight:1.1,letterSpacing:-2}}>Codex Billboards</Interactive.Div>
  <Interactive.Div name="Gallery scale" style={{fontFamily:'Arial, sans-serif',fontSize:46,letterSpacing:1.2,color:'#d7cfbc',marginTop:24}}>358 works across 26 rooms.</Interactive.Div>
 </AbsoluteFill>;
};
