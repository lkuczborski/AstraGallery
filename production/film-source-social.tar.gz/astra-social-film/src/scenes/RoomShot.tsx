import React from 'react';
import {AbsoluteFill,Interactive,interpolate,useCurrentFrame} from 'remotion';
type Props={title:string;eyebrow:string;duration:number};
export const RoomShot:React.FC<Props>=({title,eyebrow,duration})=>{
 const frame=useCurrentFrame();
 return <AbsoluteFill style={{justifyContent:'flex-end',padding:'0 110px 105px',color:'#eee6d2',background:'linear-gradient(0deg,rgba(9,16,19,.84),transparent 43%)',opacity:interpolate(frame,[0,9,duration-14,duration-1],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>
  <Interactive.Div name="Room context" style={{fontFamily:'Arial, sans-serif',fontSize:29,letterSpacing:4,color:'#dbc6a3',marginBottom:17}}>{eyebrow}</Interactive.Div>
  <Interactive.Div name="Room title" style={{fontFamily:'Georgia, serif',fontSize:80,lineHeight:1.12,letterSpacing:-.5}}>{title}</Interactive.Div>
 </AbsoluteFill>;
};
