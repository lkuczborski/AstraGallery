import React from 'react';
import {Composition} from 'remotion';
import {AstraSocial} from './AstraSocial';
import './index.css';
export const RemotionRoot:React.FC=()=> <Composition id="Astra-Twitter-30s" component={AstraSocial} durationInFrames={720} fps={24} width={1920} height={1080}/>;
