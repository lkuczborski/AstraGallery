import React from 'react';
import {AbsoluteFill,staticFile,useCurrentFrame} from 'remotion';
import {TransitionSeries} from '@remotion/transitions';
import {Audio} from '@remotion/media';
import {GalleryScene} from './scenes/GalleryScene';
import {OpeningShot} from './scenes/OpeningShot';
import {RoomShot} from './scenes/RoomShot';
import {ClosingInvitation} from './scenes/ClosingInvitation';

export const AstraSocial:React.FC=()=>{
 const frame=useCurrentFrame();
 const sourceFrame=frame<120?frame:frame<264?624+frame-120:frame<408?1704+frame-264:frame<528?2160+frame-408:frame<600?2736+frame-528:2807;
 return <AbsoluteFill style={{background:'#101b1c'}}>
  <GalleryScene sourceFrame={sourceFrame}/>
  <Audio src={staticFile('media/astra-social-30s.wav')}/>
  <TransitionSeries>
   <TransitionSeries.Sequence durationInFrames={120} name="Street arrival"><OpeningShot/></TransitionSeries.Sequence>
   <TransitionSeries.Sequence durationInFrames={144} name="Hall of Fame"><RoomShot title="Hall of Fame" eyebrow="THE TEN MOST-VOTED WORKS" duration={144}/></TransitionSeries.Sequence>
   <TransitionSeries.Sequence durationInFrames={144} name="Beyond the Horizon"><RoomShot title="Beyond the Horizon" eyebrow="NATURE & IMAGINATION" duration={144}/></TransitionSeries.Sequence>
   <TransitionSeries.Sequence durationInFrames={120} name="Chromatic Worlds"><RoomShot title="Chromatic Worlds" eyebrow="IDEAS IN FULL COLOUR" duration={120}/></TransitionSeries.Sequence>
   <TransitionSeries.Sequence durationInFrames={72} name="Your Billboard"><RoomShot title="Your image. Your wall." eyebrow="THE OPEN STUDIO" duration={72}/></TransitionSeries.Sequence>
   <TransitionSeries.Sequence durationInFrames={120} name="Invitation and original project credit"><ClosingInvitation/></TransitionSeries.Sequence>
  </TransitionSeries>
 </AbsoluteFill>;
};
