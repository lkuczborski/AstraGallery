import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createRequire} from 'node:module';
const runtimeRequire=createRequire('/Users/luku/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/resolve.cjs');
const {chromium}=runtimeRequire('playwright');
const base='/private/tmp/astra-perf-review';
const assets='/Users/luku/Developer/AstraGallery/public';
const mime={'.js':'text/javascript','.png':'image/png','.webp':'image/webp','.jpg':'image/jpeg','.jpeg':'image/jpeg','.glb':'model/gltf-binary'};
const missing=[];
const server=http.createServer(async(req,res)=>{
  const pathname=new URL(req.url,'http://localhost').pathname;
  if(pathname==='/'){res.setHeader('Content-Type','text/html');res.end('<!doctype html><html><body style="margin:0"><script type="module" src="/renderer-bench.js"></script></body></html>');return;}
  const root=pathname==='/renderer-bench.js'?base:assets;
  const target=path.resolve(root,'.'+pathname);
  if(!target.startsWith(root+path.sep)){res.writeHead(403).end();return;}
  try{res.setHeader('Content-Type',mime[path.extname(target)]||'application/octet-stream');res.end(await fs.readFile(target));}catch{missing.push(pathname);res.writeHead(404).end();}
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
let browser;
const errors=[];
try{
  browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,args:['--use-angle=metal','--disable-background-timer-throttling','--disable-renderer-backgrounding','--disable-backgrounding-occluded-windows']});
  const page=await browser.newPage({viewport:{width:1280,height:720},deviceScaleFactor:1});
  page.on('pageerror',error=>errors.push(String(error)));
  page.on('console',msg=>{if(msg.text().startsWith('BENCH_STAGE '))console.log(msg.text());});
  await page.goto(`http://127.0.0.1:${server.address().port}/`,{waitUntil:'load',timeout:30000});
  await page.waitForFunction(()=>window.benchmarkDone,{timeout:240000});
  const report=await page.evaluate(()=>window.benchmarkReport);
  report.pageErrors=errors;report.missingAssets=missing;report.browserVersion=await browser.version();
  await fs.writeFile(path.join(base,'renderer-results.json'),JSON.stringify(report,null,2));
  console.log(JSON.stringify(report,null,2));
}finally{await browser?.close();await new Promise(resolve=>server.close(resolve));}
