import * as THREE from '/Users/luku/Developer/AstraGallery/node_modules/three/build/three.module.js';
import {GalleryWorld} from '/Users/luku/Developer/AstraGallery/lib/gallery/world.ts';
import {chambers, EYE_HEIGHT, STREET_START} from '/Users/luku/Developer/AstraGallery/lib/gallery/layout.ts';

const renderer = new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'high-performance',preserveDrawingBuffer:false});
renderer.setPixelRatio(1);
renderer.setSize(1280,720);
renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure=1.04;
renderer.shadowMap.enabled=true;
renderer.shadowMap.type=THREE.PCFShadowMap;
document.body.appendChild(renderer.domElement);
const camera=new THREE.PerspectiveCamera(59,1280/720,.08,270);
camera.rotation.order='YXZ';
const gl=renderer.getContext() as WebGL2RenderingContext;
const debug=gl.getExtension('WEBGL_debug_renderer_info');
const timer=gl.getExtension('EXT_disjoint_timer_query_webgl2');
const vendor=debug?gl.getParameter(debug.UNMASKED_VENDOR_WEBGL):gl.getParameter(gl.VENDOR);
const glRenderer=debug?gl.getParameter(debug.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER);
const software=/swiftshader|llvmpipe|software/i.test(glRenderer);
const report:any={viewport:[1280,720],dpr:1,preserveDrawingBuffer:gl.getContextAttributes()?.preserveDrawingBuffer,vendor,glRenderer,gpuTimerAvailable:!!timer,software,poses:[],errors:[]};
(window as any).benchmarkReport=report;
const frame=()=>new Promise<number>(r=>requestAnimationFrame(r));
const delay=(ms:number)=>new Promise(r=>setTimeout(r,ms));
const stats=(a:number[])=>{if(!a.length)return null;const s=[...a].sort((x,y)=>x-y);return {mean:a.reduce((x,y)=>x+y,0)/a.length,median:s[Math.floor(s.length/2)],p95:s[Math.min(s.length-1,Math.floor(s.length*.95))],min:s[0],max:s.at(-1),n:s.length};};
let draws=0,shadowDraws=0;
const world=new GalleryWorld(renderer);
try{
  await world.ready;
  report.mounts=world.mounts.length;
  report.meshes=0;
  world.scene.traverse((o:any)=>{if(o.isMesh){report.meshes++;o.onBeforeShadow=()=>shadowDraws++;}});
  const fame=chambers.find(c=>c.theme.id==='fame')!;
  const far=chambers.at(-1)!;
  const cases=[
    {name:'street',position:STREET_START.position,yaw:STREET_START.yaw,pitch:STREET_START.pitch},
    {name:'hall-of-fame',position:[fame.x,EYE_HEIGHT,fame.z+1],yaw:.1,pitch:.01},
    {name:far.id,position:[far.x,EYE_HEIGHT,far.z+1],yaw:.1,pitch:.01},
  ];
  for(const pose of cases){
    camera.position.fromArray(pose.position);camera.rotation.set(pose.pitch,pose.yaw,0,'YXZ');
    for(let pass=0;pass<50;pass++){
      world.update(camera,1,true);
      const pending=world.mounts.map(m=>m.pending).filter(Boolean);
      if(!pending.length)break;
      await Promise.all(pending);
    }
    await renderer.compileAsync(world.scene,camera);
    const modes=pose.name==='hall-of-fame'?['cached','automatic']:['automatic','cached'];
    const result:any={name:pose.name,position:pose.position,modes:[]};
    for(const mode of modes){
      for(const {light} of world.lights){light.shadow.autoUpdate=mode==='automatic';if(light.castShadow)light.shadow.needsUpdate=true;}
      for(let i=0;i<(software?3:12);i++){await frame();world.update(camera,1/60);renderer.render(world.scene,camera);draws++;}
      gl.finish();
      const cpu:number[]=[],cadence:number[]=[],gpu:number[]=[],calls:number[]=[],triangles:number[]=[],shadow:number[]=[];
      const queries:WebGLQuery[]=[];
      const drain=()=>{
        if(!timer)return;
        if(gl.getParameter(timer.GPU_DISJOINT_EXT)){for(const q of queries)gl.deleteQuery(q);queries.length=0;return;}
        for(let j=queries.length-1;j>=0;j--){const q=queries[j];if(gl.getQueryParameter(q,gl.QUERY_RESULT_AVAILABLE)){gpu.push(gl.getQueryParameter(q,gl.QUERY_RESULT)/1e6);gl.deleteQuery(q);queries.splice(j,1);}}
      };
      let last=await frame();
      for(let i=0;i<(software?16:90);i++){
        const now=await frame();cadence.push(now-last);last=now;shadowDraws=0;
        const q=timer?gl.createQuery():null;if(q)gl.beginQuery(timer.TIME_ELAPSED_EXT,q);
        const start=performance.now();world.update(camera,1/60);renderer.render(world.scene,camera);cpu.push(performance.now()-start);draws++;
        if(q){gl.endQuery(timer.TIME_ELAPSED_EXT);queries.push(q);}
        calls.push(renderer.info.render.calls);triangles.push(renderer.info.render.triangles);shadow.push(shadowDraws);drain();
      }
      const deadline=performance.now()+1500;while(queries.length&&performance.now()<deadline){await delay(20);drain();}
      for(const q of queries)gl.deleteQuery(q);
      result.modes.push({mode,cpuSubmissionMs:stats(cpu),rafIntervalMs:stats(cadence),gpuMs:stats(gpu),drawCalls:stats(calls),triangles:stats(triangles),shadowDraws:stats(shadow)});
      console.log('BENCH_STAGE '+JSON.stringify({pose:pose.name,mode,renderer:glRenderer,cpuMs:stats(cpu),drawCalls:stats(calls),shadowDraws:stats(shadow)}));
    }
    report.poses.push(result);
  }
  // No screenshots or image artifacts: decode the capture in-memory and inspect pixels.
  for(const {light} of world.lights)light.shadow.autoUpdate=false;
  await delay(1200);
  const before=draws;renderer.render(world.scene,camera);draws++;
  const png=renderer.domElement.toDataURL('image/png');
  const img=new Image();img.src=png;await img.decode();
  const canvas=document.createElement('canvas');canvas.width=img.width;canvas.height=img.height;
  const ctx=canvas.getContext('2d')!;ctx.drawImage(img,0,0);const pixels=ctx.getImageData(0,0,img.width,img.height).data;
  let nonBlack=0,opaque=0,min=255,max=0;
  for(let i=0;i<pixels.length;i+=4){if(pixels[i]+pixels[i+1]+pixels[i+2]>0)nonBlack++;if(pixels[i+3]===255)opaque++;min=Math.min(min,pixels[i],pixels[i+1],pixels[i+2]);max=Math.max(max,pixels[i],pixels[i+1],pixels[i+2]);}
  report.captureAfterIdle={width:img.width,height:img.height,dataUrlLength:png.length,nonBlackPixels:nonBlack,opaquePixels:opaque,channelMin:min,channelMax:max,captureRenderCount:draws-before};
}catch(error){report.errors.push(String(error));}
finally{world.dispose();renderer.dispose();(window as any).benchmarkDone=true;}
