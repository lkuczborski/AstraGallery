import React from 'react';
import {AbsoluteFill, Interactive, interpolate, useCurrentFrame} from 'remotion';
import {Star} from './OpeningTitle';
export const ClosingTitle:React.FC=()=>{
 const frame=useCurrentFrame();
 return <AbsoluteFill style={{alignItems:'center',justifyContent:'center',color:'#eee8d9',background:'#111b16',opacity:interpolate(frame,[0,24,88,95],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>
  <Interactive.Div name="Closing star" style={{color:'#c9b184',marginBottom:19}}><Star size={34}/></Interactive.Div>
  <Interactive.Div name="Closing title" style={{fontFamily:'Georgia, serif',fontSize:66,letterSpacing:11,marginLeft:11}}>ASTRA GALLERY</Interactive.Div>
  <Interactive.Div name="Closing invitation" style={{fontFamily:'Georgia, serif',fontSize:32,fontStyle:'italic',color:'#d3c8b0',marginTop:27}}>Every idea deserves a wall.</Interactive.Div>
  <Interactive.Div name="Closing collection credit" style={{fontFamily:'Arial, sans-serif',fontSize:17,letterSpacing:3,marginTop:40,color:'#a6b0a4'}}>CODEX BILLBOARDS · A COMMUNITY COLLECTION</Interactive.Div>
 </AbsoluteFill>;
};
