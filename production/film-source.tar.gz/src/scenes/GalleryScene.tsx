import React, {useLayoutEffect, useState} from 'react';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import {cancelRender, continueRender, delayRender, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import * as THREE from 'three';
import {GalleryEngine} from '../gallery/engine';
import {rooms} from '../gallery/data';
import {tourPose} from '../gallery/tour';

const ActualGallery: React.FC = () => {
  const frame=useCurrentFrame();
  const {fps,width,height}=useVideoConfig();
  const {gl,camera,scene}=useThree();
  const [engine,setEngine]=useState<GalleryEngine|null>(null);
  const [handle]=useState(()=>delayRender('Loading actual gallery artworks, furniture, and PBR maps',{timeoutInMilliseconds:120000}));
  useLayoutEffect(()=>{
    const manager=THREE.DefaultLoadingManager;
    manager.setURLModifier(url=>url.startsWith('/')?staticFile(url.slice(1)):url);
    let disposed=false;
    manager.onError=url=>cancelRender(new Error('Gallery asset failed: '+url));
    const host=document.createElement('div');
    Object.defineProperties(host,{clientWidth:{get:()=>width},clientHeight:{get:()=>height}});
    const instance=new GalleryEngine(host,{onReady:()=>{},onSelect:()=>{},onHover:()=>{},onRoom:()=>{},onError:()=>cancelRender(new Error('Gallery WebGL context lost'))},gl);
    instance.blocked=true;
    scene.background=instance.scene.background;
    scene.environment=instance.scene.environment;
    scene.fog=instance.scene.fog;
    const required=instance.mounts.filter(m=>m.room.works.indexOf(m.work)>=0&&m.room.works.indexOf(m.work)<8);
    manager.onLoad=()=>{
      if(disposed)return;
      console.log('ASTRA_READY',required.length,'artworks',instance.pendingAssets,'pending models');
      setEngine(instance);

    };
    for(const m of required){
      m.loaded=true;
      instance.textures.load(m.work.image,t=>{
        t.colorSpace=THREE.SRGBColorSpace;t.anisotropy=Math.min(8,gl.capabilities.getMaxAnisotropy());
        const material=m.surface.material as THREE.MeshStandardMaterial;
        material.map=t;material.emissiveMap=t;material.emissive.set('#ffffff');material.emissiveIntensity=.16;material.needsUpdate=true;
      });
    }
    // Full original geometry is retained; distant textures cannot load mid-render.
    for(const m of instance.mounts)m.loaded=true;
    return ()=>{disposed=true;instance.disposed=true;instance.resizeObserver.disconnect();manager.onLoad=()=>{};manager.onError=()=>{};};
  },[gl,scene,width,height,handle]);
  useLayoutEffect(()=>{
    if(!engine)return;
    const pose=tourPose(frame/fps);
    camera.position.set(...pose.position);camera.lookAt(...pose.target);camera.updateMatrixWorld();
    engine.camera.position.copy(camera.position);engine.camera.quaternion.copy(camera.quaternion);
    engine.activeRoom=rooms[pose.roomIndex];engine.updateVisibility();
    engine.groups.forEach((g,i)=>{g.visible=Math.abs(i-pose.roomIndex)<=1;});
    engine.scene.updateMatrixWorld(true);
    gl.render(scene,camera);
    continueRender(handle);
  },[engine,frame,fps,camera,gl,scene,handle]);
  return engine?<primitive object={engine.scene}/>:null;
};
export const GalleryScene: React.FC = () => {
  const {width,height}=useVideoConfig();
  return <ThreeCanvas width={width} height={height} shadows camera={{fov:57,near:.08,far:250,position:[2.6,2.7,6.2]}} gl={{antialias:true,alpha:false,preserveDrawingBuffer:true,powerPreference:'high-performance'}} dpr={1}><ActualGallery/></ThreeCanvas>;
};
