import React from 'react';
import {AbsoluteFill, Interactive, interpolate, useCurrentFrame} from 'remotion';
export const Star:React.FC<{size?:number}>=({size=30})=><svg width={size} height={size} viewBox="0 0 40 40" fill="none"><path d="M20 1L24.2 15.8L39 20L24.2 24.2L20 39L15.8 24.2L1 20L15.8 15.8L20 1Z" fill="currentColor"/><path d="M7 7L16.7 16.7M33 7L23.3 16.7M33 33L23.3 23.3M7 33L16.7 23.3" stroke="currentColor" strokeWidth=".7"/></svg>;
export const OpeningTitle:React.FC=()=>{
 const frame=useCurrentFrame();
 return <AbsoluteFill style={{alignItems:'center',justifyContent:'center',color:'#f1ead9',background:'rgba(12,19,16,.46)',opacity:interpolate(frame,[0,18,68,100],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>
  <Interactive.Div name="Astra star" style={{marginBottom:22,color:'#d4bd95'}}><Star size={38}/></Interactive.Div>
  <Interactive.Div name="Opening title" style={{fontFamily:'Georgia, serif',fontSize:96,fontWeight:400,letterSpacing:16,marginLeft:16}}>ASTRA</Interactive.Div>
  <Interactive.Div name="Opening gallery wordmark" style={{fontFamily:'Arial, sans-serif',fontSize:23,letterSpacing:12,marginTop:9,marginLeft:12}}>GALLERY</Interactive.Div>
  <Interactive.Div name="Film title" style={{fontFamily:'Georgia, serif',fontSize:30,fontStyle:'italic',marginTop:35,color:'#e2d9c6'}}>Rooms of Light</Interactive.Div>
 </AbsoluteFill>;
};
