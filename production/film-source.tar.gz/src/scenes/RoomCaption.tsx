import React from 'react';
import {AbsoluteFill, Interactive, interpolate, useCurrentFrame} from 'remotion';
export const RoomCaption:React.FC<{number:string;title:string;subtitle:string}>=({number,title,subtitle})=>{
 const frame=useCurrentFrame();
 return <AbsoluteFill style={{justifyContent:'flex-end',padding:'0 68px 78px',color:'#f1ecdf',background:'linear-gradient(0deg,rgba(11,19,15,.72) 0%,rgba(11,19,15,.05) 39%,transparent 55%)',opacity:interpolate(frame,[0,12,77,101],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>
  <Interactive.Div name="Room number" style={{fontFamily:'Arial, sans-serif',fontSize:14,letterSpacing:3,color:'#decba6',marginBottom:11}}>ASTRA / {number}</Interactive.Div>
  <Interactive.Div name="Room name" style={{fontFamily:'Georgia, serif',fontSize:38,letterSpacing:.4}}>{title}</Interactive.Div>
  <Interactive.Div name="Room description" style={{fontFamily:'Arial, sans-serif',fontSize:19,fontWeight:400,marginTop:10,color:'#dedfd4'}}>{subtitle}</Interactive.Div>
 </AbsoluteFill>;
};
