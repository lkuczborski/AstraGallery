import React from 'react';
import {Composition} from 'remotion';
import {AstraFilm} from './AstraFilm';
export const RemotionRoot: React.FC = () => <Composition id="Astra-Gallery" component={AstraFilm} durationInFrames={1560} fps={24} width={1280} height={720}/>;
