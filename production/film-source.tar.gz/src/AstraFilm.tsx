import React from 'react';
import {AbsoluteFill, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {Audio} from '@remotion/media';
import {GalleryScene} from './scenes/GalleryScene';
import {OpeningTitle} from './scenes/OpeningTitle';
import {ClosingTitle} from './scenes/ClosingTitle';
import {RoomCaption} from './scenes/RoomCaption';
import {rooms} from './gallery/data';
export const AstraFilm:React.FC=()=>{
 const frame=useCurrentFrame();
 const cutFrames=[288,504,720,936,1152,1368];
 const cutFade=Math.max(...cutFrames.map(c=>interpolate(frame,[c-5,c,c+6],[0,.95,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})));
 return <AbsoluteFill style={{background:'#0d1511'}}>
  <AbsoluteFill style={{opacity:interpolate(frame,[0,18,1538,1559],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}><GalleryScene/></AbsoluteFill>
  <Audio src={staticFile('media/astra-rooms-of-light.wav')}/>
  <Sequence from={0} durationInFrames={101} name="Opening · Rooms of Light"><OpeningTitle/></Sequence>
  <Sequence from={108} durationInFrames={102} name="01 · Hall of Fame"><RoomCaption number="01" title="Hall of Fame" subtitle={rooms[0].subtitle}/></Sequence>
  <Sequence from={305} durationInFrames={102} name="02 · Urban Canvas"><RoomCaption number="02" title="Urban Canvas" subtitle={rooms[1].subtitle}/></Sequence>
  <Sequence from={521} durationInFrames={102} name="03 · Beyond the Horizon"><RoomCaption number="03" title="Beyond the Horizon" subtitle={rooms[2].subtitle}/></Sequence>
  <Sequence from={737} durationInFrames={102} name="04 · Less, but Louder"><RoomCaption number="04" title="Less, but Louder" subtitle={rooms[3].subtitle}/></Sequence>
  <Sequence from={953} durationInFrames={102} name="05 · Chromatic Worlds"><RoomCaption number="05" title="Chromatic Worlds" subtitle={rooms[4].subtitle}/></Sequence>
  <Sequence from={1169} durationInFrames={102} name="06 · Human / Machine"><RoomCaption number="06" title="Human / Machine" subtitle={rooms[5].subtitle}/></Sequence>
  <Sequence from={1377} durationInFrames={87} name="07 · Your Billboard"><RoomCaption number="07" title="Your Billboard" subtitle="Make this wall your own."/></Sequence>
  <AbsoluteFill style={{background:'#0d1511',opacity:cutFade}}/>
  <AbsoluteFill style={{borderTop:'44px solid #0d1511',borderBottom:'44px solid #0d1511',pointerEvents:'none'}}/>
  <Sequence from={1464} durationInFrames={96} name="Closing · Every idea deserves a wall"><ClosingTitle/></Sequence>
 </AbsoluteFill>;
};
