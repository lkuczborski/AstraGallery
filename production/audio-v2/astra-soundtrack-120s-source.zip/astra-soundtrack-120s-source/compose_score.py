"""Astra — Rooms of Light. Original 120-second extended score, composed for the gallery walkthrough.
Deterministic, humanized 96 BPM arrangement for system DLS sampled instruments.
Run with Python 3; no external Python packages required for this score generator.
"""
from pathlib import Path
import json, random

rng = random.Random(606706)
BEAT = 60 / 96
BAR = 4 * BEAT
START = .35
out = Path(__file__).parent
tracks = [
    dict(name='Grand piano', program=0, volume=.82, pan=-.09, reverb=24),
    dict(name='Legato string ensemble', program=49, volume=.25, pan=.15, reverb=43),
    dict(name='Warm atmospheric pad', program=89, volume=.19, pan=-.16, reverb=48),
    dict(name='Harp arpeggio', program=46, volume=.34, pan=.32, reverb=31),
    dict(name='Acoustic bass', program=32, volume=.49, pan=0, reverb=12),
    dict(name='Celesta glints', program=8, volume=.20, pan=-.3, reverb=42),
    dict(name='Cello countermelody', program=42, volume=.26, pan=-.27, reverb=35),
]
events = []
def add(track, t, note, dur, vel=65, human=True):
    jitter = rng.uniform(-.009,.012) if human else 0
    events.append(dict(t=round(max(0, t+jitter),5), track=track, note=note,
                       duration=round(dur,5), velocity=max(1,min(127,int(vel+rng.uniform(-3,3))))))

chords = {
 'D':  (38, [50,57,62,66], [62,66,69,73,76], [62,69,74,78]),
 'Bm': (35, [47,54,59,62], [59,62,66,69,73], [59,66,71,74]),
 'G':  (31, [43,50,55,59], [55,59,62,66,69], [59,62,67,74]),
 'A':  (33, [45,52,57,61], [57,61,64,69,71], [61,64,69,73]),
 'F#m':(30, [42,49,54,57], [57,61,66,69,73], [57,64,66,73]),
 'Em': (28, [40,47,52,55], [55,59,64,66,71], [59,64,67,71]),
}
original_progression=['D','Bm','G','A', 'D','G','Bm','A', 'G','D','Em','A', 'Bm','G','D','A', 'G','D','Em','A', 'Bm','G','A','D']
# Long, singable melodic phrases. A few ninths give the architecture a luminous color.
original_melody=[
 [(2,69,1.7)],
 [(0,74,1.4),(1.5,78,.9),(2.5,76,.5),(3,74,.8)],
 [(0,74,1.4),(1.5,71,1),(3,69,.8)],
 [(0,73,1.5),(2,76,1.7)],
 [(0,78,1.45),(1.5,81,.9),(2.5,78,.5),(3,76,.8)],
 [(0,74,2.4),(2.5,71,1.2)],
 [(0,74,1),(1.5,78,1),(3,81,.8)],
 [(0,80,1.3),(1.5,76,1),(3,73,.8)],
 [(0,74,1.5),(2,78,.8),(3,81,.8)],
 [(0,81,1.5),(2,78,1.7)],
 [(0,79,1.5),(2,78,.9),(3,76,.8)],
 [(0,76,1.8),(2.5,73,1.1)],
 [(0,78,1),(1.5,81,.9),(2.5,83,1.1)],
 [(0,86,1.45),(1.5,83,.9),(2.5,81,1.1)],
 [(0,81,1.45),(1.5,78,.9),(2.5,76,.5),(3,74,.8)],
 [(0,76,2),(2.5,73,1.1)],
 [(0,74,1.4),(1.5,78,1),(3,81,.8)],
 [(0,81,1.45),(1.5,78,.9),(2.5,76,.5),(3,74,.8)],
 [(0,76,1.4),(1.5,79,1),(3,78,.8)],
 [(0,76,1.5),(2,73,1.6)],
 [(0,74,2),(2.5,78,1.1)],
 [(0,74,2.9)],
 [(0,73,1.4),(1.5,76,.9),(2.5,81,.9)],
 [(0,78,1.3),(1.5,74,4.5)],
]
# Every section is newly arranged. Original themes return in different textures;
# no rendered audio is looped, stretched, or concatenated.
plan=[]
def bars(harmony, tunes, style):
    for chord,tune in zip(harmony,tunes):
        plan.append((chord,tune,style))

bars(['D','D','Bm','Bm','G','A'],[
    [],[(.8,69,2.5)],[(1.4,74,2.2)],[(.3,78,1.4),(2.1,76,1.4)],
    [(.5,74,2.8)],[(1.2,73,2.1)]
], 'arrival')
bars(['D','Bm','G','A','D','G'],original_melody[:6], 'theme')
bars(['Bm','A'],[
    [(0,74,2.8)],[(1,73,2.4)]
], 'breath')
bars(['Bm','A','G','D','Em','A'],original_melody[6:12], 'develop')
bars(['Em','A'],[
    [(.4,71,2.8)],[(1.3,73,2.2)]
], 'breath')
bars(['Bm','G','D','A','G','D'],original_melody[12:18], 'rise')
bars(['Em','A'],[
    [(.5,76,2.9)],[(1.4,73,2.1)]
], 'breath')
# A complementary phrase gives the second half its own contour.
bars(['D','F#m','Bm','G','Em','A'],[
    [(0,74,1.4),(1.7,78,.7),(2.7,81,1.1)],
    [(0,80,1.9),(2.3,78,1.3)],
    [(0,78,1.2),(1.6,74,.9),(3,73,.8)],
    [(.2,74,2.6),(3.2,71,.65)],
    [(0,71,1.45),(1.7,76,.9),(3,78,.75)],
    [(0,76,2.3),(2.7,73,.95)]
], 'answer')
bars(['G','A'],[
    [(.5,74,2.8)],[(1.4,76,1.9)]
], 'breath')
bars(['Bm','G','A','D'],[
    [(0,78,1.3),(1.6,81,.8),(2.7,78,1.1)],
    [(0,74,1.8),(2.4,71,1.25)],
    [(0,73,1.5),(1.8,76,.8),(2.9,81,.85)],
    [(.2,78,1.25),(1.8,74,2.0)]
], 'reprise')
bars(['G','F#m','A','D'],[
    [(.8,74,2.6)],[(.7,73,2.6)],[(.2,73,1.3),(1.8,76,1.4)],
    [(0,78,1.2),(1.7,74,5.2)]
], 'coda')
assert len(plan)==46
styles={
    'arrival':dict(power=.51,strings=False,bass=False,arp=0),
    'theme':dict(power=.74,strings=True,bass=True,arp=4),
    'breath':dict(power=.50,strings=True,bass=False,arp=0),
    'develop':dict(power=.82,strings=True,bass=True,arp=4),
    'rise':dict(power=.97,strings=True,bass=True,arp=8),
    'answer':dict(power=.85,strings=True,bass=True,arp=4),
    'reprise':dict(power=.81,strings=True,bass=True,arp=4),
    'coda':dict(power=.58,strings=True,bass=True,arp=0),
}
for bar,(name,tune,style) in enumerate(plan):
    t=START+bar*BAR
    root,keys,pad,arp=chords[name]
    cfg=styles[style]
    intensity=cfg['power']
    if style=='arrival':intensity+=bar*.018
    if style=='coda':intensity-=max(0,bar-42)*.035
    final=bar==45
    # Slower harmonic attacks give the opening and thresholds room to breathe.
    accompaniment=keys if cfg['bass'] else keys[1:]
    if style=='arrival' and bar in (1,3):
        accompaniment=[keys[-2],keys[-1]]
    delay=.16 if style=='breath' else 0
    for j,note in enumerate(accompaniment):
        add(0,t+delay+j*.039,note,4.65 if final else 2.1,47*intensity+10)
    if style in ['rise','develop'] and bar%3!=1:
        for j,note in enumerate(keys[1:]):
            add(0,t+2.2*BEAT+j*.032,note,.9,37*intensity+9)
    if cfg['strings'] or bar>=4:
        string_notes=pad[:4] if style not in ['breath','coda'] else [pad[0],pad[2],pad[3]]
        for j,note in enumerate(string_notes):
            add(1,t+.085+j*.013,note,3.9 if final else BAR-.19,52*intensity)
    # Open fifths and thirds form a warm continuous background.
    for note in [keys[1],pad[0],pad[2]]:
        add(2,t+.07,note,4.1 if final else BAR-.10,31*intensity+9)
    if cfg['bass']:
        add(4,t+.052,root,4.2 if final else BAR-.14,51*intensity+10)
        if style=='rise' and bar%2==0:
            add(4,t+2.5*BEAT,root+12,.65,35)
    if cfg['arp']:
        pattern=[0,2,1,3,0,2,1,3] if bar%2==0 else [0,1,2,3,1,2,0,3]
        for k,idx in enumerate(pattern):
            if cfg['arp']==4 and k%2:continue
            # End each group with space instead of a mechanical uninterrupted loop.
            if bar in (11,19,27,35,41) and k>=6:continue
            add(3,t+k*BEAT/2,arp[idx],.70,34*intensity+(8 if k==0 else 2))
    if bar in [6,14,22,30,38,45]:
        for k,note in enumerate([pad[0]+24,pad[2]+24]):
            add(5,t+k*BEAT,note,3,36 if bar<42 else 27)
    for beat,note,duration in tune:
        add(0,t+beat*BEAT,note,duration*BEAT,59*intensity+12)
    if style in ['develop','rise','answer']:
        celloline=[keys[2],keys[2]+2 if name in ['D','G','Em'] else keys[1]+7]
        # Cello answers in the gaps of the original piano theme.
        add(6,t+.2,celloline[0],1.35,40*intensity)
        if bar%2==0:add(6,t+2.4*BEAT,celloline[1],.88,35*intensity)

# A previous note-off must never prematurely stop a later note of the same pitch.
by_voice={}
for event in sorted(events,key=lambda e:e['t']):
    key=(event['track'],event['note'])
    previous=by_voice.get(key)
    if previous and previous['t']+previous['duration']>=event['t']:
        previous['duration']=round(max(.025,event['t']-previous['t']-.014),5)
    by_voice[key]=event
score=dict(title='Astra — Rooms of Light (The Walkthrough)',composer='Original score created for Astra Gallery',
           bpm=96,duration=120.0,key='D major',tracks=tracks,events=sorted(events,key=lambda e:e['t']),
           sections=[dict(bar=i,start=round(START+i*BAR,2),chord=p[0],style=p[2]) for i,p in enumerate(plan)])
(out/'score.json').write_text(json.dumps(score,indent=2))
print(f'Created {len(events)} original note events across {len(plan)} bars; duration {score["duration"]} seconds')
