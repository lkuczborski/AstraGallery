"""Verify exact decoded length, stereo signal, no clipping, and delivery size."""
from pathlib import Path
import json, subprocess, numpy as np

base=Path(__file__).parent
ffmpeg='/opt/homebrew/bin/ffmpeg'
ffprobe='/opt/homebrew/bin/ffprobe'
report={}
for suffix in ['wav','mp3','m4a']:
    path=base/('astra-rooms-of-light-120s.'+suffix)
    info=json.loads(subprocess.check_output([ffprobe,'-v','error','-show_entries','format=duration,size:stream=codec_name,sample_rate,channels,bits_per_raw_sample','-of','json',str(path)]))
    raw=subprocess.check_output([ffmpeg,'-v','error','-i',str(path),'-ar','44100','-ac','2','-f','f32le','-'])
    audio=np.frombuffer(raw,dtype='<f4').reshape(-1,2)
    peak=float(np.max(np.abs(audio)))
    decoded_seconds=len(audio)/44100
    item=dict(probe=info,decoded_seconds=decoded_seconds,decoded_frames=len(audio),size_bytes=path.stat().st_size,
              peak_dbfs=round(float(20*np.log10(peak)),3),finite=bool(np.isfinite(audio).all()),
              stereo_channel_difference_rms=float(np.sqrt(np.mean((audio[:,0]-audio[:,1])**2))),
              last_100ms_peak=float(np.max(np.abs(audio[-4410:]))))
    # AAC can expose encoder-frame tail padding. The WAV and gapless MP3 must be exact.
    assert decoded_seconds==120.0 if suffix!='m4a' else abs(decoded_seconds-120.0)<.03
    assert item['finite'] and peak<1
    assert item['stereo_channel_difference_rms']>.0001
    if suffix=='mp3':assert item['size_bytes']<5_000_000
    if suffix=='wav':
        item['section_rms_dbfs']={}
        for name,start,end in [('arrival',0,15),('theme',16,29),('threshold_one',31,34.8),('development',37,49),('threshold_two',51,54.8),('rise',57,69),('threshold_three',71,74.8),('answer',77,89),('threshold_four',91,94.8),('reprise',97,104),('coda',106,115)]:
            a=audio[int(start*44100):int(end*44100)]
            item['section_rms_dbfs'][name]=round(float(20*np.log10(np.sqrt(np.mean(a*a)))),2)
    report[suffix]=item
# Independent final master loudness measurement.
result=subprocess.run([ffmpeg,'-hide_banner','-i',str(base/'astra-rooms-of-light-120s.wav'),'-af','loudnorm=I=-18.5:TP=-1.2:LRA=14:print_format=json','-f','null','-'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
stderr=result.stderr.decode();start=stderr.rfind('{')
report['final_loudness']=json.loads(stderr[start:stderr.find('}',start)+1])
(base/'validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:{'duration':v['decoded_seconds'],'bytes':v['size_bytes'],'peak_dbfs':v['peak_dbfs']} for k,v in report.items() if k!='final_loudness'},indent=2))
print('Final LUFS:',report['final_loudness']['input_i'],'True peak:',report['final_loudness']['input_tp'],'LRA:',report['final_loudness']['input_lra'])
