"""Add restrained original percussion and master the rendered original score.
Requires numpy and FFmpeg; no network, samples, or third-party music used.
"""
from pathlib import Path
import json, subprocess, numpy as np

HERE=Path(__file__).parent
FFMPEG='/opt/homebrew/bin/ffmpeg'
SR=44100
DURATION=120
rng=np.random.default_rng(550184)

def run(cmd):
    return subprocess.run(cmd,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)

raw=run([FFMPEG,'-v','error','-i',str(HERE/'instruments.wav'),'-f','f32le','-ac','2','-ar',str(SR),'-']).stdout
music=np.frombuffer(raw,dtype='<f4').reshape(-1,2).copy()
music*=3.0
perc=np.zeros_like(music)

def place(signal,t,amp,pan=0):
    i=round(t*SR)
    n=min(len(signal),len(perc)-i)
    if n<=0:return
    angle=(pan+1)*np.pi/4
    perc[i:i+n,0]+=signal[:n]*(amp*np.cos(angle))
    perc[i:i+n,1]+=signal[:n]*(amp*np.sin(angle))

def kick():
    t=np.arange(int(.65*SR))/SR
    phase=2*np.pi*(48*t+24*.026*(1-np.exp(-t/.026)))
    env=(1-np.exp(-t/.002))*np.exp(-t/.16)
    return np.sin(phase)*env+.17*np.sin(2*np.pi*108*t)*np.exp(-t/.022)

def brush():
    n=int(.08*SR);t=np.arange(n)/SR
    noise=rng.normal(0,1,n)
    spec=np.fft.rfft(noise);f=np.fft.rfftfreq(n,1/SR)
    spec*=np.minimum(1,(f/4800)**3)*np.exp(-(f/12500)**4)
    sound=np.fft.irfft(spec,n)
    return sound*np.exp(-t/.018)*(1-np.exp(-t/.001))

def rim():
    t=np.arange(int(.17*SR))/SR
    tone=np.sin(2*np.pi*820*t)+.7*np.sin(2*np.pi*1236*t)+.25*np.sin(2*np.pi*2450*t)
    return tone*np.exp(-t/.014)*(1-np.exp(-t/.0008))

beat=60/96
for bar in [*range(14,20),*range(22,28),*range(30,36),*range(38,42)]:
    base=.35+bar*4*beat
    energy=.46 if bar<20 else .79 if bar<28 else .62 if bar<36 else .46
    place(kick(),base,.043*energy)
    if 22<=bar<28:place(kick(),base+2.5*beat,.023*energy)
    if bar%2==0:place(rim(),base+2*beat,.011*energy,-.18)
    for j in range(8):
        amp=.0052*energy*(.75 if j%2==0 else 1.0)*rng.uniform(.75,1)
        place(brush(),base+j*beat/2+rng.uniform(-.007,.007),amp,.45 if j%2 else -.38)
# Small room on percussion keeps the pulse integrated, with no big snare hits.
for sec,gain in [(0.071,.12),(0.127,.08),(0.193,.04)]:
    offset=int(sec*SR)
    perc[offset:]+=perc[:-offset,::-1]*gain
mix=music+perc
# A quiet, diffuse stereo halo carries the ending.
for sec,gain in [(0.293,.016),(0.419,.013)]:
    offset=int(sec*SR)
    mix[offset:]+=music[:-offset,::-1]*gain
# Smoothly land in true silence while allowing the last chord to resolve.
time=np.arange(len(mix))/SR
fadein=np.sin(np.minimum(time/.22,1)*np.pi/2)**2
fadeout=np.cos(np.clip((time-115.5)/4.5,0,1)*np.pi/2)**2
mix*=fadein[:,None]*fadeout[:,None]
mix=np.tanh(mix*1.08)/1.08
rawpath=HERE/'premaster.f32'
mix.astype('<f4').tofile(rawpath)
base=[FFMPEG,'-hide_banner','-y','-f','f32le','-ar',str(SR),'-ac','2','-i',str(rawpath)]
analysis=run(base+['-af','highpass=f=30,loudnorm=I=-18.5:TP=-1.2:LRA=14:print_format=json','-f','null','-']).stderr.decode()
start=analysis.rfind('{')
measure=json.loads(analysis[start:analysis.find('}',start)+1])
(HERE/'loudness-analysis.json').write_text(json.dumps(measure,indent=2))
settings=f"highpass=f=30,loudnorm=I=-18.5:TP=-1.2:LRA=14:measured_I={measure['input_i']}:measured_TP={measure['input_tp']}:measured_LRA={measure['input_lra']}:measured_thresh={measure['input_thresh']}:offset={measure['target_offset']}:linear=true:print_format=summary"
output=HERE/'astra-rooms-of-light-120s.wav'
metadata=['-metadata','title=Astra — Rooms of Light (The Walkthrough)','-metadata','artist=Original score for Astra Gallery','-metadata','comment=Original instrumental composition; 96 BPM; D major; 120 seconds; continuous original arrangement.']
result=run(base+['-af',settings,'-ar',str(SR),'-c:a','pcm_s24le']+metadata+[str(output)])
print(result.stderr.decode().split('Output Integrated:')[-1])
run([FFMPEG,'-v','error','-y','-i',str(output),'-c:a','libmp3lame','-b:a','192k']+metadata+[str(HERE/'astra-rooms-of-light-120s.mp3')])
run([FFMPEG,'-v','error','-y','-i',str(output),'-c:a','aac','-b:a','192k','-movflags','+faststart']+metadata+[str(HERE/'astra-rooms-of-light-120s.m4a')])
rawpath.unlink()
print('Delivered WAV (24-bit), MP3 (192 kb/s), M4A (192 kb/s)')
