# Astra — Rooms of Light (The Walkthrough)

A new, continuous 120-second arrangement of the original Astra Gallery instrumental. The familiar piano theme is developed through a spacious arrival, contrasting phrases, quieter thresholds, a gentle rise, and a resolved ending. No section of rendered music is looped or time-stretched.

## Deliverables

- `astra-rooms-of-light-120s.mp3` — stereo MP3, 192 kb/s; designed to remain below 5 MB
- `astra-rooms-of-light-120s.wav` — 44.1 kHz stereo, 24-bit PCM master, exactly 120.000 seconds
- `astra-rooms-of-light-120s.m4a` — alternate AAC encode at 192 kb/s
- `compose_score.py`, `render_score.swift`, `master_audio.py`, `score.json` — reproducible original composition, sampler rendering, and mastering source
- `validation.json`, `loudness-analysis.json` — format, duration, signal, and mastering measurements

## Musical cue sheet

These cues are soft arrangement changes suitable for a human walkthrough; they do not require cuts on exact frames.

| Time | Character |
| --- | --- |
| 0–15.35 s | Spacious street arrival; sparse piano and warm pad, strings gradually appearing |
| 15.35–30.35 s | The original piano theme enters, with restrained harp and bass |
| 30.35–35.35 s | First quiet threshold; melody held with room around it |
| 35.35–50.35 s | Theme development; cello replies and a very soft pulse |
| 50.35–55.35 s | Second threshold; percussion and bass step away |
| 55.35–70.35 s | Main emotional rise, with higher piano and fuller strings |
| 70.35–75.35 s | Quiet threshold and release |
| 75.35–90.35 s | A complementary piano phrase with a softer, varied accompaniment |
| 90.35–95.35 s | Final quiet threshold |
| 95.35–105.35 s | A gentle reprise of the familiar motif |
| 105.35–115.5 s | Open, unhurried coda; final D-major chord begins at 112.85 s |
| 115.5–120 s | Resonance fades smoothly to silence |

## Musical details

96 BPM, D major, 46 bars plus a natural ending. Seven sampled instruments: grand piano, legato strings, warm pad, harp, acoustic bass, celesta, and cello. Original synthesized brushed percussion is kept sparse and absent from the quieter thresholds. No vocals or artist imitation.

## Recreate on macOS

Requires Swift, Python 3 with NumPy, and FFmpeg. The sampler uses Apple's system General MIDI DLS bank; the bank and samples are not redistributed. Offline rendering requires access to the macOS audio component service, but does not play audio aloud.

```sh
python3 compose_score.py
swiftc -module-cache-path ./swift-cache render_score.swift -o render_score
./render_score score.json instruments.wav
python3 master_audio.py
```

FFmpeg in this environment: `/opt/homebrew/bin/ffmpeg`.
