from pathlib import Path
import hashlib,json,subprocess,struct,re
root=Path(__file__).parent
movie=root/'out/astra-gallery-rooms-of-light-v3.mp4'
def command(*args):
 return subprocess.run(args,check=True,text=True,capture_output=True)
metadata=json.loads(command('ffprobe','-v','error','-show_format','-show_streams','-of','json',str(movie)).stdout)
video=next(s for s in metadata['streams'] if s['codec_type']=='video')
audio=next(s for s in metadata['streams'] if s['codec_type']=='audio')
assert video['codec_name']=='h264' and video['width']==1920 and video['height']==1080
assert video['r_frame_rate']=='24/1' and int(video['nb_frames'])==2880
assert audio['codec_name']=='aac' and audio['channels']==2
for duration in [metadata['format']['duration'],video['duration'],audio['duration']]:assert abs(float(duration)-120)<.001
assert movie.stat().st_size<25*1024*1024
command('ffmpeg','-v','error','-i',str(movie),'-f','null','-')
volume=command('ffmpeg','-hide_banner','-i',str(movie),'-vn','-af','volumedetect','-f','null','-').stderr
(root/'diagnostics/audio-volume.log').write_text(volume)
blob=movie.read_bytes();atoms=[];offset=0
while offset+8<=len(blob):
 size,kind=struct.unpack('>I4s',blob[offset:offset+8]);size=struct.unpack('>Q',blob[offset+8:offset+16])[0] if size==1 else size
 if not size:break
 atoms.append({'kind':kind.decode('ascii'),'offset':offset,'size':size});offset+=size
assert next(a['offset'] for a in atoms if a['kind']=='moov')<next(a['offset'] for a in atoms if a['kind']=='mdat')
frames=[48,216,384,456,720,1056,1176,1464,1728,1920,2040,2196,2376,2640,2736,2844]
selection='+'.join(f'eq(n,{n})' for n in frames)
command('ffmpeg','-v','error','-i',str(movie),'-vf',f"select='{selection}',scale=480:-1,tile=4x4",'-frames:v','1','-y',str(root/'out/film-contact-sheet.jpg'))
raw=subprocess.run(['ffmpeg','-v','error','-i',str(movie),'-an','-vf','crop=1920:948:0:66,scale=32:16','-pix_fmt','rgb24','-f','rawvideo','-'],check=True,capture_output=True).stdout
frameBytes=32*16*3;uniformFrames=[]
for frame in range(len(raw)//frameBytes):
 pixels=raw[frame*frameBytes:(frame+1)*frameBytes]
 variance=sum(sum(v*v for v in pixels[c::3])/512-(sum(pixels[c::3])/512)**2 for c in range(3))/3
 if variance<4 and 16<=frame<2860 and not any(abs(frame-t*24)<=6 for t in [48,70,84,97,110]):uniformFrames.append(frame)
assert not uniformFrames, f'Unexpected uniform scene frames: {uniformFrames}'
report={'unexpectedUniformFrames':uniformFrames,'file':str(movie),'bytes':movie.stat().st_size,'sha256':hashlib.sha256(blob).hexdigest(),'fullDecodePassed':True,'faststart':True,'atoms':atoms,'audioMeanDb':float(re.search(r'mean_volume: ([-.0-9]+) dB',volume).group(1)),'audioPeakDb':float(re.search(r'max_volume: ([-.0-9]+) dB',volume).group(1)),'contactSheetFrames':frames,'metadata':metadata}
(root/'diagnostics/media-validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ['metadata','atoms']},indent=2))
