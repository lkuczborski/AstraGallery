import React from 'react';
import {Composition} from 'remotion';
import {AstraFilm} from './AstraFilm';
import './index.css';
export const RemotionRoot:React.FC=()=> <Composition id="Astra-Gallery-v3" component={AstraFilm} durationInFrames={2880} fps={24} width={1920} height={1080}/>;
