import React from 'react';
import {AbsoluteFill,CanvasImage,Interactive,interpolate,staticFile,useCurrentFrame} from 'remotion';
export const ClosingTitle:React.FC=()=>{
 const frame=useCurrentFrame();
 return <AbsoluteFill style={{alignItems:'center',justifyContent:'center',background:'#10191f',color:'#e8ddc7',opacity:interpolate(frame,[0,16,55,71],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>
  <CanvasImage src={staticFile('brand/astra-gallery-logo-v2.png')} width={1150} height={1150/3}/>
  <Interactive.Div name="Closing invitation" style={{fontFamily:'Georgia, serif',fontSize:41,fontStyle:'italic',marginTop:0}}>Every idea deserves a wall.</Interactive.Div>
  <Interactive.Div name="Collection credit" style={{fontFamily:'Arial, sans-serif',fontSize:19,letterSpacing:4,color:'#abb5b4',marginTop:38}}>CODEX BILLBOARDS · A COMMUNITY COLLECTION</Interactive.Div>
 </AbsoluteFill>;
};
