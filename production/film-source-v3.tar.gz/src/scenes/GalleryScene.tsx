import React,{useLayoutEffect,useState} from 'react';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import {cancelRender,continueRender,delayRender,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import * as THREE from 'three';
import {GalleryWorld} from '../gallery/world';
import {tourPose,TOUR_DURATION} from '../gallery/tour';
const SOURCE_FPS=24;
const visitedChambers=Array.from(new Set(Array.from({length:TOUR_DURATION*4+1},(_,i)=>tourPose(i/4).chamberId).filter((v):v is string=>Boolean(v))));
type TimelineMetadata={frames:number;fps:number;slots:number;stride:number;mountIds:string[];castShadow:boolean[];sha256:string};
type Prepared={world:GalleryWorld;timeline:Float32Array;metadata:TimelineMetadata};
export type SceneProps={sourceFrame?:number;diagnostics?:boolean;inspectionCamera?:{position:[number,number,number];target:[number,number,number]}};
const ActualWorld:React.FC<SceneProps>=({sourceFrame,diagnostics=false,inspectionCamera})=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();const recordedFrame=Math.max(0,Math.min(TOUR_DURATION*SOURCE_FPS-1,Math.round(sourceFrame??frame*SOURCE_FPS/fps)));
 const {gl,scene,camera}=useThree();const [prepared,setPrepared]=useState<Prepared|null>(null);
 const [handle]=useState(()=>delayRender('Loading current Astra Gallery, artwork textures and recorded walking lights',{timeoutInMilliseconds:180000}));
 useLayoutEffect(()=>{
  let stopped=false;const started=performance.now();
  THREE.DefaultLoadingManager.setURLModifier(url=>url.startsWith('/')?staticFile(url.slice(1)):url);
  gl.outputColorSpace=THREE.SRGBColorSpace;gl.toneMapping=THREE.ACESFilmicToneMapping;gl.toneMappingExposure=1.04;gl.shadowMap.enabled=true;gl.shadowMap.type=THREE.PCFShadowMap;
  const world=new GalleryWorld(gl);scene.background=world.scene.background;scene.environment=world.scene.environment;scene.environmentIntensity=world.scene.environmentIntensity;scene.fog=world.scene.fog;
  Promise.all([
   world.ready.then(()=>world.preloadDetails(visitedChambers)),
   fetch(staticFile('media/lighting-v3.json')).then(r=>{if(!r.ok)throw new Error('Lighting metadata failed');return r.json() as Promise<TimelineMetadata>;}),
   fetch(staticFile('media/lighting-v3.bin')).then(r=>{if(!r.ok)throw new Error('Lighting timeline failed');return r.arrayBuffer();}),
  ]).then(([,metadata,buffer])=>{
   if(stopped)return;const timeline=new Float32Array(buffer);
   if(timeline.length!==metadata.frames*metadata.slots*metadata.stride||metadata.fps!==SOURCE_FPS)throw new Error('Invalid light timeline dimensions');
   if(metadata.mountIds.length!==world.mounts.length||metadata.mountIds.some((id,i)=>world.mounts[i].placement.work.id!==id))throw new Error('Lighting timeline does not match world artwork ordering');
   if(metadata.castShadow.some((value,i)=>world.lights[i].light.castShadow!==value))throw new Error('Lighting timeline shadow slots do not match current world');
   const wanted=world.mounts.filter(m=>m.placement.work.id!=='your-billboard'&&visitedChambers.includes(m.placement.chamber.id));
   const missing=wanted.filter(m=>!m.preview||!m.detail);if(missing.length)throw new Error('Film artwork textures missing: '+missing.map(m=>m.placement.work.id).join(', '));
   for(const m of wanted){m.blend=1;m.uniforms.detailBlend.value=1;}
   console.log('ASTRA_V3_READY '+JSON.stringify({seconds:(performance.now()-started)/1000,chambers:visitedChambers,fullResolutionArtworks:wanted.length,lightingHash:metadata.sha256}));
   setPrepared({world,timeline,metadata});
  }).catch(error=>{if(!stopped)cancelRender(error)});
  return()=>{stopped=true;world.disposed=true;};
 },[gl,scene]);
 useLayoutEffect(()=>{
  if(!prepared)return;const {world,timeline,metadata}=prepared;
  const pose=inspectionCamera??tourPose(recordedFrame/SOURCE_FPS);camera.position.set(...pose.position);camera.lookAt(...pose.target);camera.updateMatrixWorld(true);
  if(inspectionCamera){
   // Static diagnostic camera only. Production and teaser frames always replay history.
   world.update(camera,1/SOURCE_FPS,true);
  }else{
   for(let slot=0;slot<metadata.slots;slot++){
    const offset=(recordedFrame*metadata.slots+slot)*metadata.stride;const item=world.lights[slot],mountIndex=timeline[offset];
    item.mount=mountIndex<0?null:world.mounts[mountIndex];item.light.intensity=timeline[offset+1];
    item.light.position.fromArray(timeline,offset+2);item.light.target.position.fromArray(timeline,offset+5);
   }
  }
  world.scene.updateMatrixWorld(true);gl.render(scene,camera);
  if(diagnostics){const context=gl.getContext();context.finish();const samples:number[]=[];for(let i=0;i<5;i++){const start=performance.now();gl.render(scene,camera);context.finish();samples.push(performance.now()-start);}const gpu=context.getExtension('WEBGL_debug_renderer_info');console.log('ASTRA_V3_METRICS '+JSON.stringify({compositionFrame:frame,sourceFrame:recordedFrame,seconds:recordedFrame/SOURCE_FPS,inspection:Boolean(inspectionCamera),calls:gl.info.render.calls,triangles:gl.info.render.triangles,textures:gl.info.memory.textures,synchronizedRenderMs:samples,renderer:gpu?context.getParameter(gpu.UNMASKED_RENDERER_WEBGL):null,lights:world.lights.map((item,slot)=>({slot,work:item.mount?.placement.work.id,intensity:item.light.intensity,castShadow:item.light.castShadow}))}));}
  continueRender(handle);
 },[prepared,frame,recordedFrame,camera,gl,scene,handle,diagnostics,inspectionCamera]);
 return prepared?<primitive object={prepared.world.scene}/>:null;
};
export const GalleryScene:React.FC<SceneProps>=(props)=>{const {width,height}=useVideoConfig();return <ThreeCanvas width={width} height={height} dpr={1} shadows camera={{fov:59,near:.08,far:270,position:[4,1.78,31]}} gl={{antialias:true,alpha:false,powerPreference:'high-performance',preserveDrawingBuffer:true}}><ActualWorld {...props}/></ThreeCanvas>};
