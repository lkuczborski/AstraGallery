import React from 'react';
import {AbsoluteFill,Interactive,interpolate,useCurrentFrame} from 'remotion';
export const RoomCaption:React.FC<{title:string;subtitle:string}>=({title,subtitle})=>{
 const frame=useCurrentFrame();
 return <AbsoluteFill style={{justifyContent:'flex-end',padding:'0 105px 136px',color:'#ece5d6',background:'linear-gradient(0deg,rgba(9,15,19,.7),transparent 43%)',opacity:interpolate(frame,[0,15,69,95],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>
  <Interactive.Div name="Room title" style={{fontFamily:'Georgia, serif',fontSize:49,letterSpacing:.4}}>{title}</Interactive.Div>
  <Interactive.Div name="Room atmosphere" style={{fontFamily:'Arial, sans-serif',fontSize:24,color:'#c4c6bb',marginTop:14}}>{subtitle}</Interactive.Div>
 </AbsoluteFill>;
};
