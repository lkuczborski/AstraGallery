import React from 'react';
import {AbsoluteFill,Interactive,interpolate,useCurrentFrame} from 'remotion';
export const OpeningTitle:React.FC=()=>{
 const frame=useCurrentFrame();
 return <AbsoluteFill style={{justifyContent:'flex-end',padding:'0 105px 160px',color:'#eee6d2',background:'linear-gradient(0deg,rgba(9,15,19,.75),transparent 55%)',opacity:interpolate(frame,[0,20,77,107],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>
  <Interactive.Div name="Film introduction" style={{fontFamily:'Arial, sans-serif',fontSize:19,letterSpacing:5,color:'#c6bca6',marginBottom:17}}>A WALK THROUGH ASTRA GALLERY</Interactive.Div>
  <Interactive.Div name="Rooms of Light title" style={{fontFamily:'Georgia, serif',fontSize:76,fontWeight:400,letterSpacing:.7}}>Rooms of Light</Interactive.Div>
 </AbsoluteFill>;
};
