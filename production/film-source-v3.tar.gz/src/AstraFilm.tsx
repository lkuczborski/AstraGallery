import React from 'react';
import {AbsoluteFill,Sequence,interpolate,staticFile,useCurrentFrame} from 'remotion';
import {Audio} from '@remotion/media';
import {GalleryScene,type SceneProps} from './scenes/GalleryScene';
import {OpeningTitle} from './scenes/OpeningTitle';
import {ClosingTitle} from './scenes/ClosingTitle';
import {RoomCaption} from './scenes/RoomCaption';
import {TOUR_CUT_TIMES} from './gallery/tour';
export type FilmProps=SceneProps&{showTitles?:boolean};
export const AstraFilm:React.FC<FilmProps>=({showTitles=true,...sceneProps})=>{
 const frame=useCurrentFrame();
 const cuts=Math.max(0,...TOUR_CUT_TIMES.map(time=>interpolate(frame,[time*24-5,time*24,time*24+6],[0,.97,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})));
 return <AbsoluteFill style={{background:'#0b1115'}}>
  <AbsoluteFill style={{opacity:showTitles?interpolate(frame,[0,16,2860,2879],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'}):1}}><GalleryScene {...sceneProps}/></AbsoluteFill>
  <Audio src={staticFile('media/astra-rooms-of-light-120s.wav')}/>
  {showTitles&&<>
   <Sequence from={12} durationInFrames={108} name="Opening · Rooms of Light"><OpeningTitle/></Sequence>
   <Sequence from={432} durationInFrames={96} name="Hall of Fame"><RoomCaption title="Hall of Fame" subtitle="The community’s most celebrated ideas."/></Sequence>
   <Sequence from={1032} durationInFrames={96} name="The Courtyard"><RoomCaption title="The Courtyard" subtitle="A moment beneath the open sky."/></Sequence>
   <Sequence from={1164} durationInFrames={96} name="Urban Canvas"><RoomCaption title="Urban Canvas" subtitle="Big ideas. Real-world stages."/></Sequence>
   <Sequence from={1452} durationInFrames={96} name="Less, but Louder"><RoomCaption title="Less, but Louder" subtitle="Clarity is a creative act."/></Sequence>
   <Sequence from={1692} durationInFrames={96} name="Beyond the Horizon"><RoomCaption title="Beyond the Horizon" subtitle="A different kind of landscape."/></Sequence>
   <Sequence from={2028} durationInFrames={96} name="Chromatic Worlds"><RoomCaption title="Chromatic Worlds" subtitle="Ideas in full colour."/></Sequence>
   <Sequence from={2340} durationInFrames={96} name="Human / Machine"><RoomCaption title="Human / Machine" subtitle="At the intersection of culture and code."/></Sequence>
   <Sequence from={2664} durationInFrames={96} name="Your Billboard"><RoomCaption title="Your Billboard" subtitle="Make this wall your own."/></Sequence>
   <AbsoluteFill style={{background:'#0b1115',opacity:cuts}}/>
   <Sequence from={2808} durationInFrames={72} name="Closing invitation"><ClosingTitle/></Sequence>
  </>}
  <AbsoluteFill style={{borderTop:'66px solid #0b1115',borderBottom:'66px solid #0b1115',pointerEvents:'none'}}/>
 </AbsoluteFill>;
};
