import {bundle} from '@remotion/bundler';
import {openBrowser,selectComposition,renderStill} from '@remotion/renderer';
import fs from 'node:fs/promises';
import path from 'node:path';
const root='/private/tmp/astra-film-v2';
const serveUrl=await bundle({entryPoint:path.join(root,'src/index.ts'),rootDir:root,outDir:path.join(root,'out/inspection-bundle'),publicDir:path.join(root,'public')});
const browser=await openBrowser('chrome',{chromiumOptions:{gl:'angle'}});
const tests=[
 {name:'01-street-revised',frame:36},
 {name:'06-velvet-palette',frame:2148,inspectionCamera:{position:[43.8,1.78,-51],target:[34,3.0,-57]}},
];
const reports=[];
try{
 for(const test of tests){
  const inputProps={diagnostics:true,showTitles:false,...(test.inspectionCamera?{inspectionCamera:test.inspectionCamera}:{})};
  const logs=[];const onBrowserLog=log=>{if(log.text.startsWith('ASTRA_')){logs.push(log.text);console.log(log.text)}};
  const composition=await selectComposition({serveUrl,id:'Astra-Gallery-v2',inputProps,puppeteerInstance:browser,onBrowserLog});
  const start=Date.now();
  await renderStill({serveUrl,composition,output:path.join(root,'out',test.name+'.png'),frame:test.frame,inputProps,puppeteerInstance:browser,onBrowserLog,timeoutInMilliseconds:180000,overwrite:true});
  reports.push({...test,wallClockSeconds:(Date.now()-start)/1000,logs});
  await fs.writeFile(path.join(root,'out/render-diagnostics-palette.json'),JSON.stringify(reports,null,2));
 }
}finally{await browser.close({silent:true});}
