import React,{useLayoutEffect,useState} from 'react';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import {cancelRender,continueRender,delayRender,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import * as THREE from 'three';
import {GalleryWorld} from '../gallery/world';
import {tourPose,TOUR_DURATION} from '../gallery/tour';

const visitedChambers=Array.from(new Set(Array.from({length:TOUR_DURATION*4+1},(_,i)=>tourPose(i/4).chamberId).filter((v):v is string=>Boolean(v))));
export type SceneProps={diagnostics?:boolean;inspectionCamera?:{position:[number,number,number];target:[number,number,number]}};
const ActualWorld:React.FC<SceneProps>=({diagnostics=false,inspectionCamera})=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();
 const {gl,scene,camera}=useThree();const [world,setWorld]=useState<GalleryWorld|null>(null);
 const [handle]=useState(()=>delayRender('Loading exact Astra Gallery world and visited artworks',{timeoutInMilliseconds:180000}));
 useLayoutEffect(()=>{
  let stopped=false;const started=performance.now();
  THREE.DefaultLoadingManager.setURLModifier(url=>url.startsWith('/')?staticFile(url.slice(1)):url);
  gl.outputColorSpace=THREE.SRGBColorSpace;gl.toneMapping=THREE.ACESFilmicToneMapping;gl.toneMappingExposure=1.04;gl.shadowMap.enabled=true;gl.shadowMap.type=THREE.PCFShadowMap;
  const instance=new GalleryWorld(gl);
  scene.background=instance.scene.background;scene.environment=instance.scene.environment;scene.environmentIntensity=instance.scene.environmentIntensity;scene.fog=instance.scene.fog;
  instance.ready.then(()=>instance.preloadDetails(visitedChambers)).then(()=>{
   if(stopped)return;
   const wanted=instance.mounts.filter(m=>m.placement.work.id!=='your-billboard'&&visitedChambers.includes(m.placement.chamber.id));
   const missing=wanted.filter(m=>!m.preview||!m.detail);
   if(missing.length)throw new Error('Film artwork textures missing: '+missing.map(m=>m.placement.work.id).join(', '));
   console.log('ASTRA_V2_READY',JSON.stringify({seconds:(performance.now()-started)/1000,chambers:visitedChambers,fullResolutionArtworks:wanted.length}));
   setWorld(instance);
  }).catch(error=>{if(!stopped)cancelRender(error)});
  return()=>{stopped=true;instance.disposed=true;};
 },[gl,scene]);
 useLayoutEffect(()=>{
  if(!world)return;
  const pose=inspectionCamera??tourPose(frame/fps);camera.position.set(...pose.position);camera.lookAt(...pose.target);camera.updateMatrixWorld(true);
  world.update(camera,1/24,true);world.scene.updateMatrixWorld(true);
  gl.render(scene,camera);
  if(diagnostics){
   const context=gl.getContext();context.finish();const samples:number[]=[];
   for(let i=0;i<5;i++){const start=performance.now();gl.render(scene,camera);context.finish();samples.push(performance.now()-start);}
   const gpu=context.getExtension('WEBGL_debug_renderer_info');
   console.log('ASTRA_V2_METRICS '+JSON.stringify({frame,seconds:frame/fps,calls:gl.info.render.calls,triangles:gl.info.render.triangles,textures:gl.info.memory.textures,geometries:gl.info.memory.geometries,programs:gl.info.programs?.length,synchronizedRenderMs:samples,renderer:gpu?context.getParameter(gpu.UNMASKED_RENDERER_WEBGL):null}));
  }
  continueRender(handle);
 },[world,frame,fps,camera,gl,scene,handle,diagnostics,inspectionCamera]);
 return world?<primitive object={world.scene}/>:null;
};
export const GalleryScene:React.FC<SceneProps>=(props)=>{
 const {width,height}=useVideoConfig();
 return <ThreeCanvas width={width} height={height} dpr={1} shadows camera={{fov:59,near:.08,far:270,position:[4,1.78,31]}} gl={{antialias:true,alpha:false,powerPreference:'high-performance',preserveDrawingBuffer:true}}><ActualWorld {...props}/></ThreeCanvas>;
};
